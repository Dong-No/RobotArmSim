#!/usr/bin/env python

import rospy
import sys,math
from std_msgs.msg import Float64
from std_msgs.msg import Float64MultiArray
from moveit_msgs.msg import DisplayTrajectory
from trajectory_msgs.msg import JointTrajectory,JointTrajectoryPoint

global joint_angle,del_theta
joint_angle = Float64MultiArray()
joint_angle.data = [0,math.pi/2,-math.pi/2,-math.pi/2]
del_theta = 3.0 * math.pi / 180

def angle_limit(theta):

    if theta > math.pi:
        theta = math.pi
    elif theta < -math.pi:
        theta = -math.pi

def pub_cmd_to_joint():
    global pub,rate,joint_angle
    rospy.init_node('joint_position_pub', anonymous=True)
    pub = rospy.Publisher('/myrobot/four_joints_position_controllers/command', Float64MultiArray, queue_size=10)
    # rate = rospy.Rate(100) # 100hz
    

def sub_to_moveit():
	rospy.Subscriber("/move_group/display_planned_path",DisplayTrajectory,callback)

def callback(msg_get):
    # msg_get = DisplayTrajectory
    global joint_angle
    for ele in  msg_get.trajectory:

        a_list = ele.joint_trajectory.points
        for e in  a_list:
            joint_angle.data = e.positions
            # print "line 41",joint_angle.data

            for angle in joint_angle.data:
                angle_limit(angle)
    
            pub.publish(joint_angle)
            rospy.sleep(0.01)

if __name__ == '__main__':


    print "moveit_gazebo_interface ok!"   
    pub_cmd_to_joint()

    pub.publish(joint_angle)
    sub_to_moveit()
    rospy.spin()

   
   
    
        
    
