#!/usr/bin/env python

from tf.transformations import quaternion_from_euler

a=quaternion_from_euler(-1.57079633,0,0)
print a[0]==float(a[0])

pub_point_rviz = rospy.Publisher("visualization_marker", Marker, queue_size=10)
self.pub_point_rviz = pub_point_rviz
P=Marker()
    P.POINTS
    P.header.frame_id = "world"
    P.scale.x = 0.1
    P.scale.x = 0.1
    P.pose = pose_goal.pose
    P.color.g = 1.0
    P.action = Marker.ADD
    self.pub_point_rviz.publish(P)