#!/usr/bin/env python


## BEGIN_SUB_TUTORIAL imports
##
## To use the Python MoveIt interfaces, we will import the `moveit_commander`_ namespace.
## This namespace provides us with a `MoveGroupCommander`_ class, a `PlanningSceneInterface`_ class,
## and a `RobotCommander`_ class. More on these below. We also import `rospy`_ and some messages that we will use:
##

import sys
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
from math import atan2, acos, asin, sqrt, sin, cos, pi
from moveit_commander.conversions import pose_to_list
## END_SUB_TUTORIAL

l0 = 0.06
l1 = 0.082
l2 = 0.132
l3 = 0.1664

def all_close(goal, actual, tolerance):
  """
  Convenience method for testing if a list of values are within a tolerance of their counterparts in another list
  @param: goal       A list of floats, a Pose or a PoseStamped
  @param: actual     A list of floats, a Pose or a PoseStamped
  @param: tolerance  A float
  @returns: bool
  """
  all_equal = True
  if type(goal) is list:
    for index in range(len(goal)):
      if abs(actual[index] - goal[index]) > tolerance:
        return False

  elif type(goal) is geometry_msgs.msg.PoseStamped:
    return all_close(goal.pose, actual.pose, tolerance)

  elif type(goal) is geometry_msgs.msg.Pose:
    return all_close(pose_to_list(goal), pose_to_list(actual), tolerance)

  return True


class MoveGroupPythonIntefaceTutorial(object):
  """MoveGroupPythonIntefaceTutorial"""
  def __init__(self):
    super(MoveGroupPythonIntefaceTutorial, self).__init__()

    ## BEGIN_SUB_TUTORIAL setup
    ##
    ## First initialize `moveit_commander`_ and a `rospy`_ node:
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('move_group_python_interface_tutorial', anonymous=True)

    ## Instantiate a `RobotCommander`_ object. Provides information such as the robot's
    ## kinematic model and the robot's current joint states
    robot = moveit_commander.RobotCommander()

    ## Instantiate a `PlanningSceneInterface`_ object.  This provides a remote interface
    ## for getting, setting, and updating the robot's internal understanding of the
    ## surrounding world:
    scene = moveit_commander.PlanningSceneInterface()

    ## Instantiate a `MoveGroupCommander`_ object.  This object is an interface
    ## to a planning group (group of joints).  In this tutorial the group is the primary
    ## arm joints in the Panda robot, so we set the group's name to "panda_arm".
    ## If you are using a different robot, change this value to the name of your robot
    ## arm planning group.
    ## This interface can be used to plan and execute motions:
    group_name = "ldsc_arm"
    move_group = moveit_commander.MoveGroupCommander(group_name)

    ## Create a `DisplayTrajectory`_ ROS publisher which is used to display
    ## trajectories in Rviz:
    display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                                   moveit_msgs.msg.DisplayTrajectory,
                                                   queue_size=20)

    ## END_SUB_TUTORIAL

    


    ## BEGIN_SUB_TUTORIAL basic_info
    ##
    ## Getting Basic Information
    ## ^^^^^^^^^^^^^^^^^^^^^^^^^
    # We can get the name of the reference frame for this robot:
    planning_frame = move_group.get_planning_frame()
    print "============ Planning frame: %s" % planning_frame


    move_group.set_workspace([-0.2984,-0.2984,0.0,0.2984,0.2984,0.4404])



    # We can get a list of all the groups in the robot:
    group_names = robot.get_group_names()
    # print "============ Available Planning Groups:", robot.get_group_names()

    # Sometimes for debugging it is useful to print the entire state of the
    # robot:
    # print "============ Printing robot state"
    # print robot.get_current_state()
    # print ""
    ## END_SUB_TUTORIAL

    # Misc variables
    

    self.robot = robot
    self.scene = scene
    self.move_group = move_group
    self.display_trajectory_publisher = display_trajectory_publisher
    self.planning_frame = planning_frame
    
    self.group_names = group_names

    j = move_group.get_current_joint_values()
    self.j = j




  def go_to_joint_state(self):
    
    move_group = self.move_group
    j = self.j

    joint_goal = move_group.get_current_joint_values()

    joint_goal[0] = j[0]
    joint_goal[1] = j[1]
    joint_goal[2] = j[2]
    joint_goal[3] = j[3]

    # The go command can be called with joint values, poses, or without any
    # parameters if you have already set the pose or joint target for the group
    move_group.go(joint_goal, wait=True)

    # Calling ``stop()`` ensures that there is no residual movement
    move_group.stop()
    ## END_SUB_TUTORIAL

    # For testing:
    current_joints = move_group.get_current_joint_values()
    # print "current joints:" , current_joints
    current_pose = self.move_group.get_current_pose().pose
    print "current pose:" , current_pose.position 
    return all_close(joint_goal, current_joints, 0.01)

  def now_pose(self):
    print "current pose:", self.move_group.get_current_pose()

  def get_constraints(self):
    print "path constraints:", self.move_group.get_path_constraints()




def Simplest_IK(x,y,z):
    
  global l0,l1,l2,l3
  joint_angle = [0,0,0,0]
  
  L = sqrt(x**2+y**2+(z-l0-l1)**2)

  cos_j3 = (L**2 - l2**2 - l3**2)/(2*l2*l3)

  if abs(cos_j3) > 1: ##arm can't reach
    SOLUTION_FOUND =  False
  
  elif abs(cos_j3-1) < 0.0001 : ##prevent float == float, cos_j3 ==1

    '''the longest distance that the arm can reach,
    which is a sphere with r = l2+l3 centered at joint2,
    j3 has unique one solution = 0 deg
    '''
    SOLUTION_FOUND =  [atan2(sqrt(x**2 + y**2),z-l0-l1 ) , 0]
    print "max sphere"

  
  elif abs(cos_j3+1) < 0.0001:  ##prevent float == float, cos_j3 ==-1
    if x == 0 and y ==0:#because L2 != L3,but moveit will also detect collision
      SOLUTION_FOUND =  False
    else:
      SOLUTION_FOUND =  [atan2(sqrt(x**2 + y**2),z-l0-l1 ) , pi]
      print "min sphere"

  else:
    j3_two_sol = [acos(cos_j3),-acos(cos_j3)]
    a = atan2(sqrt(x**2 + y**2),z-l0-l1 )
    
    j2_two_sol = [0,0]
    for i in range(len(j2_two_sol)):
      j2_two_sol[i] = a - atan2(l3*sin(j3_two_sol[i]),l2+l3*cos(j3_two_sol[i]))

    SOLUTION_FOUND =  [j2_two_sol[0],j3_two_sol[0],j2_two_sol[1],j3_two_sol[1]]

  if SOLUTION_FOUND != False:

    if len(SOLUTION_FOUND)==2:
      joint_angle[1] = SOLUTION_FOUND[0]##joint2
      joint_angle[2] = SOLUTION_FOUND[1]##joint3

    elif len(SOLUTION_FOUND)==4:
        if abs(SOLUTION_FOUND[0]) < 2.0 and abs(SOLUTION_FOUND[1])<1.67:

          '''check if solution of j2 and j3 exceed limit''' 
          joint_angle[1] = SOLUTION_FOUND[0]##joint2
          joint_angle[2] = SOLUTION_FOUND[1]##joint3
          print '216'

        elif abs(SOLUTION_FOUND[2]) < 2.0 and abs(SOLUTION_FOUND[3])<1.67:

          '''check if solution of j2 and j3 exceed limit'''
          joint_angle[1] = SOLUTION_FOUND[2]##joint2
          joint_angle[2] = SOLUTION_FOUND[3]##joint3
          print '223'
        else:
          print "arm can''t reach"
          return

  else:
    print "arm can''t reach"
    return
  
  joint_angle[0] = atan2(y,x)
  joint_angle[3] = pi/2 - joint_angle[1] - joint_angle[2] ## 4th joint

  

  if abs(joint_angle[0]) <= pi/2:##xy (+,+) or (+,-) : x > 0 
    pass
  else:##xy (-,-) or (-,+) : x < 0 
    joint_angle[0] = joint_angle[0] + pi
    joint_angle[1] = - joint_angle[1]
    joint_angle[2] = - joint_angle[2]
    joint_angle[3] = - joint_angle[3]


  joint_angle = map_into_pi_pi(joint_angle)
  

  if not structure_limit(joint_angle):
    print "over structure limit"
    print [1.2, 2, 1.67, pi/2]
    print joint_angle
    return 

  
  return joint_angle

def map_into_pi_pi(joint_list):

  temp_list = [0,0,0,0]## be careful: some issues over changing list value in Python 
  for i in range(len(joint_list)):
      while joint_list[i] > pi:
        joint_list[i] = joint_list[i] - 2*pi
      while joint_list[i] < -pi:
        joint_list[i] = joint_list[i] + 2*pi
      temp_list[i] = joint_list[i]
  return temp_list

def structure_limit(joint_list):
  '''real arm joint limit'''
  limit = [1.2, 2, 1.67, pi/2]
  for i in range(len(joint_list)):
    if abs(joint_list[i]) > limit[i] :
      return False
  
  return True
    

def main():
  try:
    tutorial = MoveGroupPythonIntefaceTutorial()
    while not rospy.is_shutdown():
    
        print "============ key in xyz to execute a movement using a pose goal ..."
        
        try:
          xi=float(raw_input("x:  "))
          yi=float(raw_input("y:  "))
          zi=float(raw_input("z:  "))

          buffer = Simplest_IK(xi,yi,zi)
          if buffer != None:
            tutorial.j = buffer 
            tutorial.go_to_joint_state()
          else:
            continue
        except:
          tutorial.j = [0,-pi/2,pi/2,0] 
          tutorial.go_to_joint_state()

  except rospy.ROSInterruptException:
    return
  except KeyboardInterrupt:
    return

if __name__ == '__main__':
  main()

