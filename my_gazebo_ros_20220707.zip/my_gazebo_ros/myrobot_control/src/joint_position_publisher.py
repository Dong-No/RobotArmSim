#!/usr/bin/env python3
#-*- coding:UTF-8 -*-

import	rospy 
import	math
from std_msgs.msg import Float64



def talker():
	pub1 = rospy.Publisher('/myrobot/joint1_position_controller/command', Float64, queue_size=10)
	pub2 = rospy.Publisher('/myrobot/joint2_position_controller/command', Float64, queue_size=10)
	pub3 = rospy.Publisher('/myrobot/joint3_position_controller/command', Float64, queue_size=10)
	rospy.init_node('pub', anonymous=True)#note publisher is also a node
	rate = rospy.Rate(10) # 10hz

	
	while not rospy.is_shutdown():
			
		joint_position1 = float(input())#double(float64),float32 issue
		joint_position2 = float(input())
		joint_position3 = float(input())
		#joint_position=math.sin(math.pi)
		rospy.loginfo("position1: %s",joint_position1)#print to screen
		rospy.loginfo("position2: %s",joint_position2)#print to screen
		rospy.loginfo("position3: %s",joint_position3)#print to screen
		pub1.publish(joint_position1)#pub to Topic
		pub2.publish(joint_position2)
		pub3.publish(joint_position3)
		rate.sleep()#maybe 10HZ?

if __name__ == '__main__':
	try:
		talker()
	except rospy.ROSInterruptException:
		pass
